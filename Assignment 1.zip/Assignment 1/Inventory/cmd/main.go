package main

import (
	"context"
	"log"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/golang-jwt/jwt/v5"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"

	"inventory/internal/delivery"
	"inventory/internal/repo"
	"inventory/internal/usecase"
)

// JWT Secret Key (Replace with a secure key in production)
var jwtSecret = []byte("your-secret-key")

// AuthMiddleware validates JWT tokens
func AuthMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		tokenString := c.GetHeader("Authorization")
		if tokenString == "" {
			c.AbortWithStatusJSON(401, gin.H{"error": "Unauthorized"})
			return
		}

		token, err := jwt.Parse(tokenString, func(token *jwt.Token) (interface{}, error) {
			return jwtSecret, nil
		})
		if err != nil || !token.Valid {
			c.AbortWithStatusJSON(401, gin.H{"error": "Invalid token"})
			return
		}

		c.Next()
	}
}

// LoginHandler generates a JWT token
func LoginHandler(c *gin.Context) {
	// Replace this with actual user authentication logic
	username := c.PostForm("username")
	password := c.PostForm("password")

	// Example: Check username and password (hardcoded for demonstration)
	if username != "admin" || password != "password" {
		c.JSON(401, gin.H{"error": "Invalid credentials"})
		return
	}

	// Create a new token
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims{
		"username": username,
		"exp":      time.Now().Add(time.Hour * 24).Unix(), // Token expires in 24 hours
	})

	// Sign the token with the secret key
	tokenString, err := token.SignedString(jwtSecret)
	if err != nil {
		c.JSON(500, gin.H{"error": "Failed to generate token"})
		return
	}

	c.JSON(200, gin.H{"token": tokenString})
}

func main() {
	// MongoDB setup
	client, err := mongo.NewClient(options.Client().ApplyURI("mongodb://localhost:27017"))
	if err != nil {
		log.Fatal("Mongo client error:", err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	err = client.Connect(ctx)
	if err != nil {
		log.Fatal("Mongo connect error:", err)
	}

	// Repo/UseCase setup
	productRepo := repo.NewProductMongoRepo(client, "inventoryDB")
	productUseCase := usecase.NewProductUseCase(productRepo)

	// Start server
	router := gin.Default()

	// Public routes
	router.POST("/login", LoginHandler)
	router.GET("/health", func(c *gin.Context) {
		c.JSON(200, gin.H{"status": "Inventory MongoDB service OK"})
	})

	// Protected routes (require JWT authentication)
	authGroup := router.Group("/")
	authGroup.Use(AuthMiddleware())
	delivery.RegisterProductRoutes(authGroup, productUseCase)

	log.Println("Running Inventory Service on port 8081 with MongoDB and JWT...")
	router.Run(":8081")
}
